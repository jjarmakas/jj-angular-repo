#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Registers a Scheduled Task that starts the WebSphere Log Shipper utility
    at every Windows startup, running continuously as the SYSTEM account.

.DESCRIPTION
    Runs under SYSTEM for simplicity (no credentials to store/rotate). This
    only works if the destination share's permissions grant access to this
    machine's computer account (COMPUTERNAME$) or to "Authenticated Users" /
    "Everyone" as appropriate for your environment. If the share instead
    requires a specific service account, re-run this script's
    Register-ScheduledTask call with a -Credential-based principal instead
    of SYSTEM.

    The task is configured to:
      - Start at system boot (no user logon required)
      - Restart automatically on failure (up to 999 times, 1 minute apart)
      - Run with no execution time limit (this is a long-running process)
      - Never start a second instance if one is already running

.PARAMETER JarPath
    Full path to log-shipper.jar (default: ..\dist\log-shipper.jar next to this script).

.PARAMETER ConfigPath
    Full path to log-shipper.properties (default: alongside the jar).

.PARAMETER JavaExe
    Full path to java.exe (default: resolved from JAVA_HOME or PATH).

.PARAMETER TaskName
    Scheduled task name (default: WebSphereLogShipper).

.EXAMPLE
    .\Install-LogShipperTask.ps1
#>
[CmdletBinding()]
param(
    [string]$JarPath,
    [string]$ConfigPath,
    [string]$JavaExe,
    [string]$TaskName = 'WebSphereLogShipper',
    [string]$MaxHeap = '256m'
)

$ErrorActionPreference = 'Stop'

$scriptDir = $PSScriptRoot
$root = Split-Path -Parent $scriptDir

if (-not $JarPath) { $JarPath = Join-Path $root 'dist\log-shipper.jar' }
if (-not $ConfigPath) { $ConfigPath = Join-Path (Split-Path -Parent $JarPath) 'log-shipper.properties' }

if (-not (Test-Path $JarPath)) {
    throw "Jar not found at $JarPath. Run build.ps1 first, or pass -JarPath explicitly."
}
if (-not (Test-Path $ConfigPath)) {
    throw "Config not found at $ConfigPath. Copy/edit config\log-shipper.properties first, or pass -ConfigPath explicitly."
}

if (-not $JavaExe) {
    if ($env:JAVA_HOME) {
        $candidate = Join-Path $env:JAVA_HOME 'bin\java.exe'
        if (Test-Path $candidate) { $JavaExe = $candidate }
    }
    if (-not $JavaExe) {
        $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
        if ($cmd) { $JavaExe = $cmd.Source }
    }
    if (-not $JavaExe) {
        throw "java.exe not found. Pass -JavaExe explicitly or set JAVA_HOME."
    }
}

$workingDir = Split-Path -Parent $JarPath

# -Xms/-Xmx bound heap for a small, steady workload. SerialGC keeps
# background GC activity (and therefore CPU) minimal for a light,
# mostly-idle, long-running utility.
$javaArgs = "-Xms64m -Xmx$MaxHeap -XX:+UseSerialGC -jar `"$JarPath`" `"$ConfigPath`""

Write-Host "Task name:    $TaskName"
Write-Host "Java exe:     $JavaExe"
Write-Host "Java args:    $javaArgs"
Write-Host "Working dir:  $workingDir"
Write-Host "Run as:       SYSTEM"

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Write-Host "Existing task '$TaskName' found, removing before re-registering..."
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

$action = New-ScheduledTaskAction -Execute $JavaExe -Argument $javaArgs -WorkingDirectory $workingDir
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -MultipleInstances IgnoreNew

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger `
    -Principal $principal -Settings $settings `
    -Description 'Ships WebSphere historical log files (SystemOut_*.log) to a network share so they survive WebSphere''s own size-based log rotation purge.' | Out-Null

Write-Host ""
Write-Host "Task '$TaskName' registered. It will start at next reboot."
Write-Host "To start it immediately without rebooting, run:"
Write-Host "  Start-ScheduledTask -TaskName '$TaskName'"
Write-Host "To check status:"
Write-Host "  Get-ScheduledTask -TaskName '$TaskName' | Get-ScheduledTaskInfo"
