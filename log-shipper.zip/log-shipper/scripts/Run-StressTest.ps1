#Requires -Version 5.1
<#
.SYNOPSIS
    Runs the log-shipper rotation stress test utility.

.DESCRIPTION
    Continuously renames a set of 10 dummy log files in the configured
    source.dir, incrementing their sequence number every couple of seconds,
    to simulate WebSphere rotating its historical log files while
    log-shipper is running against the same folder.

    Expects dist\log-shipper.jar to already be built (see build.ps1).
    By default, expects 10 files named SystemOut_Stress1.log ..
    SystemOut_Stress10.log to already exist in the configured source.dir.
    Pass -Seed to have the tool create them first.

.PARAMETER ConfigPath
    Full path to log-shipper.properties (default: dist\log-shipper.properties).

.PARAMETER IntervalSeconds
    How often to rotate the files, in seconds (default: 2).

.PARAMETER Seed
    Create the 10 initial SystemOut_Stress1..10.log files before starting,
    if none are already present.

.EXAMPLE
    .\Run-StressTest.ps1 -Seed

.EXAMPLE
    .\Run-StressTest.ps1 -IntervalSeconds 3
#>
[CmdletBinding()]
param(
    [string]$JarPath,
    [string]$ConfigPath,
    [string]$JavaExe,
    [int]$IntervalSeconds = 2,
    [switch]$Seed
)

$ErrorActionPreference = 'Stop'

$scriptDir = $PSScriptRoot
$root = Split-Path -Parent $scriptDir

if (-not $JarPath) { $JarPath = Join-Path $root 'dist\log-shipper.jar' }
if (-not $ConfigPath) { $ConfigPath = Join-Path (Split-Path -Parent $JarPath) 'log-shipper.properties' }

if (-not (Test-Path $JarPath)) {
    throw "Jar not found at $JarPath. Run build.ps1 first, or pass -JarPath explicitly."
}
if (-not (Test-Path $ConfigPath)) {
    throw "Config not found at $ConfigPath. Copy/edit config\log-shipper.properties first, or pass -ConfigPath explicitly."
}

if (-not $JavaExe) {
    if ($env:JAVA_HOME) {
        $candidate = Join-Path $env:JAVA_HOME 'bin\java.exe'
        if (Test-Path $candidate) { $JavaExe = $candidate }
    }
    if (-not $JavaExe) {
        $cmd = Get-Command java.exe -ErrorAction SilentlyContinue
        if ($cmd) { $JavaExe = $cmd.Source }
    }
    if (-not $JavaExe) {
        throw "java.exe not found. Pass -JavaExe explicitly or set JAVA_HOME."
    }
}

$javaArgs = @('-cp', $JarPath, 'com.jj.logshipper.StressRotator', $ConfigPath, $IntervalSeconds)
if ($Seed) { $javaArgs += '--seed' }

Write-Host "Starting stress rotator (interval: ${IntervalSeconds}s). Press Ctrl+C to stop."
& $JavaExe @javaArgs
