#Requires -Version 5.1
<#
.SYNOPSIS
    Compiles the WebSphere Log Shipper utility and packages it as a runnable jar.
    Requires a JDK 8 (javac/jar) on PATH or reachable via JAVA_HOME.
#>
[CmdletBinding()]
param(
    [string]$JavaHome = $env:JAVA_HOME
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$src = Join-Path $root 'src\main\java'
$outClasses = Join-Path $root 'out\classes'
$dist = Join-Path $root 'dist'
$jarPath = Join-Path $dist 'log-shipper.jar'

function Resolve-JavaTool([string]$toolName) {
    if ($JavaHome) {
        $candidate = Join-Path $JavaHome "bin\$toolName.exe"
        if (Test-Path $candidate) { return $candidate }
    }
    $cmd = Get-Command $toolName -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw "$toolName not found. Set -JavaHome or add the JDK's bin directory to PATH."
}

$javac = Resolve-JavaTool 'javac'
$jarTool = Resolve-JavaTool 'jar'

Write-Host "Using javac: $javac"
Write-Host "Using jar:   $jarTool"

if (Test-Path $outClasses) { Remove-Item $outClasses -Recurse -Force }
New-Item -ItemType Directory -Path $outClasses -Force | Out-Null
if (-not (Test-Path $dist)) { New-Item -ItemType Directory -Path $dist -Force | Out-Null }

$sourceFiles = Get-ChildItem -Path $src -Filter '*.java' -Recurse | Select-Object -ExpandProperty FullName
if (-not $sourceFiles) { throw "No .java files found under $src" }

$sourcesListFile = Join-Path $env:TEMP 'log-shipper-sources.txt'
$sourceFiles | ForEach-Object { '"' + $_ + '"' } | Set-Content -Path $sourcesListFile -Encoding ASCII

& $javac -source 8 -target 8 -d $outClasses "@$sourcesListFile"
if ($LASTEXITCODE -ne 0) { throw "javac failed with exit code $LASTEXITCODE" }

$manifestFile = Join-Path $env:TEMP 'log-shipper-manifest.txt'
"Main-Class: com.jj.logshipper.LogShipper`n" | Set-Content -Path $manifestFile -Encoding ASCII

Push-Location $outClasses
try {
    & $jarTool cfm $jarPath $manifestFile .
    if ($LASTEXITCODE -ne 0) { throw "jar failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}

Copy-Item -Path (Join-Path $root 'config\log-shipper.properties') -Destination $dist -Force

Write-Host ""
Write-Host "Build complete: $jarPath"
Write-Host "Edit $dist\log-shipper.properties (source.dir / dest.dir) before first run."
Write-Host "Test manually with:  java -jar `"$jarPath`""
