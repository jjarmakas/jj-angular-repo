package com.jj.logshipper;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.regex.Pattern;

/**
 * Loads and validates the utility's configuration from a .properties file.
 */
final class Config {

    final Path sourceDir;
    final Path destDir;
    final Pattern filePattern;
    final int pollIntervalSeconds;
    final int minAgeSeconds;
    final Path logDir;
    final int logFileSizeMb;
    final int logFileCount;
    final String logLevel;

    private Config(Path sourceDir, Path destDir, Pattern filePattern, int pollIntervalSeconds,
                    int minAgeSeconds, Path logDir, int logFileSizeMb, int logFileCount, String logLevel) {
        this.sourceDir = sourceDir;
        this.destDir = destDir;
        this.filePattern = filePattern;
        this.pollIntervalSeconds = pollIntervalSeconds;
        this.minAgeSeconds = minAgeSeconds;
        this.logDir = logDir;
        this.logFileSizeMb = logFileSizeMb;
        this.logFileCount = logFileCount;
        this.logLevel = logLevel;
    }

    static Config load(Path propertiesFile) throws IOException {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(propertiesFile)) {
            p.load(in);
        }

        String source = require(p, "source.dir");
        String dest = require(p, "dest.dir");
        String pattern = p.getProperty("file.pattern", "SystemOut_.*\\.log");
        int pollInterval = Integer.parseInt(p.getProperty("poll.interval.seconds", "15"));
        int minAge = Integer.parseInt(p.getProperty("min.age.seconds", "5"));
        String logDirStr = p.getProperty("log.dir", ".\\logs");
        int logSizeMb = Integer.parseInt(p.getProperty("log.file.size.mb", "5"));
        int logCount = Integer.parseInt(p.getProperty("log.file.count", "5"));
        String logLevel = p.getProperty("log.level", "INFO");

        if (pollInterval < 1) {
            throw new IllegalArgumentException("poll.interval.seconds must be >= 1");
        }

        return new Config(
                Paths.get(source),
                Paths.get(dest),
                Pattern.compile(pattern, Pattern.CASE_INSENSITIVE),
                pollInterval,
                minAge,
                Paths.get(logDirStr),
                logSizeMb,
                logCount,
                logLevel);
    }

    private static String require(Properties p, String key) {
        String v = p.getProperty(key);
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing required property: " + key);
        }
        return v.trim();
    }
}
