package com.jj.logshipper;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * One scan/ship cycle: finds historical WebSphere log files that have
 * finished being written and are not yet present on the destination share,
 * and copies them over.
 *
 * Design notes:
 *  - No persistent "already shipped" ledger is kept. Instead, before copying,
 *    the destination is checked for a same-named, same-sized file. Since
 *    WebSphere never rewrites a rotated log file, a size match is proof the
 *    file was already fully copied on a previous run. This makes the utility
 *    naturally idempotent and crash-safe across restarts.
 *  - A file is only copied once its size has been unchanged across two
 *    consecutive scans AND its last-modified time is older than minAgeSeconds,
 *    so a file WebSphere is still flushing is never copied mid-write.
 *  - Copies go to a ".partial" file on the share first, then get renamed into
 *    place, so a reader (or this utility, after a crash) never sees a
 *    half-written file under the final name.
 *  - Every exception is caught inside run() so a single bad cycle (e.g. the
 *    share being temporarily offline) never kills the scheduler.
 */
final class ShippingTask implements Runnable {

    private static final Logger LOG = Logger.getLogger(ShippingTask.class.getName());
    private static final Duration DEST_UNAVAILABLE_LOG_THROTTLE = Duration.ofMinutes(5);

    private final Config config;
    private final Map<String, Long> lastSeenSizes = new HashMap<>();
    private volatile Instant lastDestUnavailableLogged = Instant.EPOCH;

    ShippingTask(Config config) {
        this.config = config;
    }

    @Override
    public void run() {
        try {
            runCycle();
        } catch (Throwable t) {
            // Never let an exception escape - the scheduler must keep running
            // for a month unattended.
            LOG.log(Level.SEVERE, "Unexpected error during scan cycle", t);
        }
    }

    private void runCycle() {
        if (!Files.isDirectory(config.sourceDir)) {
            LOG.warning("Source directory not available (yet?): " + config.sourceDir);
            return;
        }

        List<Path> candidates = listCandidates();
        Set<String> currentNames = new HashSet<>(candidates.size());

        for (Path file : candidates) {
            String name = file.getFileName().toString();
            currentNames.add(name);

            long size;
            FileTime mtime;
            try {
                size = Files.size(file);
                mtime = Files.getLastModifiedTime(file);
            } catch (IOException e) {
                // File vanished between listing and stat - skip, it'll be
                // gone from the listing next cycle.
                continue;
            }

            Long previousSize = lastSeenSizes.put(name, size);
            if (previousSize == null || previousSize.longValue() != size) {
                continue; // still changing (or first time seen) - wait for next cycle
            }

            Duration age = Duration.between(mtime.toInstant(), Instant.now());
            if (age.getSeconds() < config.minAgeSeconds) {
                continue; // not old enough yet, be conservative
            }

            shipFile(file, size);
        }

        // Bound memory: forget files that have rolled off the source
        // directory (WebSphere purges its own old historical files).
        lastSeenSizes.keySet().retainAll(currentNames);
    }

    private List<Path> listCandidates() {
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(config.sourceDir)) {
            for (Path p : stream) {
                String name = p.getFileName().toString();
                if (Files.isRegularFile(p) && config.filePattern.matcher(name).matches()) {
                    result.add(p);
                }
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "Failed to list source directory: " + config.sourceDir, e);
        }
        return result;
    }

    private void shipFile(Path source, long expectedSize) {
        Path dest = config.destDir.resolve(source.getFileName().toString());
        Path tempDest = config.destDir.resolve(source.getFileName().toString() + ".partial");

        try {
            if (Files.isRegularFile(dest) && Files.size(dest) == expectedSize) {
                return; // already shipped on a previous run/cycle
            }

            Files.createDirectories(config.destDir);
            Files.copy(source, tempDest, StandardCopyOption.REPLACE_EXISTING);

            long copiedSize = Files.size(tempDest);
            if (copiedSize != expectedSize) {
                LOG.warning("Size mismatch copying " + source.getFileName()
                        + " (expected " + expectedSize + ", got " + copiedSize + "); will retry next cycle");
                deleteQuietly(tempDest);
                return;
            }

            try {
                Files.move(tempDest, dest, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tempDest, dest, StandardCopyOption.REPLACE_EXISTING);
            }

            LOG.info("Shipped " + source.getFileName() + " (" + expectedSize + " bytes) to " + config.destDir);
        } catch (IOException e) {
            deleteQuietly(tempDest);
            logDestUnavailable(source, e);
        }
    }

    private void deleteQuietly(Path p) {
        try {
            Files.deleteIfExists(p);
        } catch (IOException ignored) {
            // best effort cleanup; a leftover .partial is harmless and will
            // be overwritten on the next successful attempt
        }
    }

    private void logDestUnavailable(Path source, IOException e) {
        Instant now = Instant.now();
        boolean unreachable = e instanceof NoSuchFileException || !Files.isDirectory(config.destDir);
        if (unreachable) {
            if (Duration.between(lastDestUnavailableLogged, now).compareTo(DEST_UNAVAILABLE_LOG_THROTTLE) < 0) {
                return; // throttle repeated "share is down" noise
            }
            lastDestUnavailableLogged = now;
            LOG.log(Level.WARNING, "Destination share unavailable, will keep retrying: " + config.destDir, e);
        } else {
            LOG.log(Level.WARNING, "Failed to ship " + source.getFileName() + ", will retry next cycle", e);
        }
    }
}
