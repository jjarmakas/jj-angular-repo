package com.jj.logshipper;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Entry point. Ships WebSphere historical log files (already rotated,
 * closed files such as SystemOut_*.log) from a local WebSphere log
 * directory to a Windows share, so they survive WebSphere's own
 * size-based log retention purge.
 *
 * Usage: java -jar log-shipper.jar [path\to\log-shipper.properties]
 * Defaults to .\log-shipper.properties (relative to the working directory
 * the process is started in).
 */
public final class LogShipper {

    private static final Logger LOG = Logger.getLogger(LogShipper.class.getName());

    private static FileLock instanceLock;
    private static FileChannel instanceLockChannel;

    public static void main(String[] args) {
        Path propsFile = Paths.get(args.length > 0 ? args[0] : "log-shipper.properties");

        Config config;
        try {
            config = Config.load(propsFile);
        } catch (Exception e) {
            System.err.println("Failed to load configuration from " + propsFile.toAbsolutePath() + ": " + e.getMessage());
            System.exit(1);
            return;
        }

        try {
            setupLogging(config);
        } catch (IOException e) {
            System.err.println("Failed to initialize logging: " + e.getMessage());
            System.exit(1);
            return;
        }

        if (!acquireSingleInstanceLock()) {
            LOG.severe("Another instance already appears to be running (lock file held). Exiting.");
            System.exit(1);
            return;
        }

        LOG.info("WebSphere Log Shipper starting. source=" + config.sourceDir
                + " dest=" + config.destDir
                + " pattern=" + config.filePattern.pattern()
                + " pollIntervalSeconds=" + config.pollIntervalSeconds
                + " minAgeSeconds=" + config.minAgeSeconds);

        ThreadFactory threadFactory = r -> {
            Thread t = new Thread(r, "log-shipper-worker");
            t.setDaemon(false);
            return t;
        };
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(threadFactory);
        ShippingTask task = new ShippingTask(config);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> shutdown(scheduler), "log-shipper-shutdown"));

        // fixedDelay (not fixedRate): if a cycle runs long because the share
        // is slow/unavailable, cycles never pile up back-to-back.
        scheduler.scheduleWithFixedDelay(task, 0, config.pollIntervalSeconds, TimeUnit.SECONDS);

        LOG.info("Scheduler started.");
    }

    private static void setupLogging(Config config) throws IOException {
        Files.createDirectories(config.logDir);
        Path logPattern = config.logDir.resolve("log-shipper-%g.log");

        Logger root = Logger.getLogger("");
        for (java.util.logging.Handler h : root.getHandlers()) {
            root.removeHandler(h);
        }

        FileHandler fileHandler = new FileHandler(
                logPattern.toString(),
                config.logFileSizeMb * 1024 * 1024,
                config.logFileCount,
                true);
        fileHandler.setFormatter(new SimpleFormatter());
        Level level = Level.parse(config.logLevel);
        fileHandler.setLevel(level);
        root.addHandler(fileHandler);
        root.setLevel(level);
    }

    private static boolean acquireSingleInstanceLock() {
        try {
            Path lockPath = Paths.get("log-shipper.lock");
            instanceLockChannel = FileChannel.open(lockPath,
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            instanceLock = instanceLockChannel.tryLock();
            return instanceLock != null;
        } catch (IOException | OverlappingFileLockException e) {
            LOG.log(Level.SEVERE, "Failed to acquire single-instance lock", e);
            return false;
        }
    }

    private static void shutdown(ScheduledExecutorService scheduler) {
        LOG.info("Shutdown signal received, stopping scheduler...");
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(10, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        try {
            if (instanceLock != null) {
                instanceLock.release();
            }
            if (instanceLockChannel != null) {
                instanceLockChannel.close();
            }
        } catch (IOException ignored) {
            // best effort on the way out
        }
        LOG.info("Stopped.");
    }

    private LogShipper() {
    }
}
