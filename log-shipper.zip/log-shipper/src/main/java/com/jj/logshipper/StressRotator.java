package com.jj.logshipper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Manual stress-test utility for log-shipper.
 *
 * Simulates WebSphere continuously rotating a fixed set of historical log
 * files by renaming them, which is the kind of churn ShippingTask has to
 * cope with (a file it's watching disappearing and an unrelated-looking
 * file appearing under a new name every couple of seconds) without ever
 * shipping a file mid-rotation.
 *
 * Setup (manual, by the operator): place exactly 10 files named
 * SystemOut_Stress1.log .. SystemOut_Stress10.log in the log folder
 * (the shipper's configured source.dir) before starting this tool, or
 * pass --seed to have it create them.
 *
 * Each cycle, all 10 files are renamed, highest sequence number first,
 * incrementing the number by 1 - so the window of 10 files keeps sliding
 * upward (1..10, then 2..11, then 3..12, ...) with no naming collisions.
 *
 * Usage:
 *   java -cp log-shipper.jar com.jj.logshipper.StressRotator [propsFile] [intervalSeconds] [--seed]
 *
 * Runs until interrupted (Ctrl+C).
 */
public final class StressRotator {

    private static final String PREFIX = "SystemOut_Stress";
    private static final String SUFFIX = ".log";
    private static final int FILE_COUNT = 10;
    private static final Pattern STRESS_FILE_PATTERN =
            Pattern.compile(Pattern.quote(PREFIX) + "(\\d+)" + Pattern.quote(SUFFIX));
    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    public static void main(String[] args) {
        Path propsFile = Paths.get("log-shipper.properties");
        int intervalSeconds = 2;
        boolean seed = false;

        List<String> positional = new ArrayList<>();
        for (String arg : args) {
            if ("--seed".equalsIgnoreCase(arg)) {
                seed = true;
            } else {
                positional.add(arg);
            }
        }
        if (positional.size() > 0) {
            propsFile = Paths.get(positional.get(0));
        }
        if (positional.size() > 1) {
            intervalSeconds = Integer.parseInt(positional.get(1));
        }
        if (intervalSeconds < 1) {
            System.err.println("intervalSeconds must be >= 1");
            System.exit(1);
            return;
        }

        Path logDir;
        try {
            logDir = Config.load(propsFile).sourceDir;
        } catch (Exception e) {
            System.err.println("Failed to load configuration from " + propsFile.toAbsolutePath() + ": " + e.getMessage());
            System.exit(1);
            return;
        }

        if (!Files.isDirectory(logDir)) {
            System.err.println("Log folder does not exist: " + logDir);
            System.exit(1);
            return;
        }

        if (seed) {
            seedInitialFiles(logDir);
        }

        int low = detectStartingSequence(logDir);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> log("Stopping."), "stress-rotator-shutdown"));

        log("Starting rotation stress test: dir=" + logDir + " intervalSeconds=" + intervalSeconds
                + " files=" + PREFIX + low + SUFFIX + " .. " + PREFIX + (low + FILE_COUNT - 1) + SUFFIX);
        log("Press Ctrl+C to stop.");

        while (true) {
            try {
                Thread.sleep(intervalSeconds * 1000L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            low = rotateOnce(logDir, low);
        }
    }

    /**
     * Creates SystemOut_Stress1.log .. SystemOut_Stress10.log with dummy
     * content, but only if the folder currently has none of the stress
     * files - so re-running with --seed against a stress run already in
     * progress (window shifted past 1..10) doesn't create a stray extra set.
     */
    private static void seedInitialFiles(Path logDir) {
        List<Integer> existing = listStressFileNumbers(logDir);
        if (!existing.isEmpty()) {
            log("--seed requested but " + existing.size() + " " + PREFIX + "*" + SUFFIX
                    + " file(s) already present; leaving them as-is.");
            return;
        }

        for (int i = 1; i <= FILE_COUNT; i++) {
            Path f = logDir.resolve(PREFIX + i + SUFFIX);
            String content = "Stress test dummy log file " + i + ", created " + LocalTime.now().format(TIMESTAMP) + System.lineSeparator();
            try {
                Files.write(f, content.getBytes(StandardCharsets.UTF_8));
            } catch (IOException e) {
                System.err.println("Failed to seed " + f + ": " + e.getMessage());
                System.exit(1);
            }
        }
        log("Seeded " + FILE_COUNT + " files: " + PREFIX + "1" + SUFFIX + " .. " + PREFIX + FILE_COUNT + SUFFIX);
    }

    private static int detectStartingSequence(Path logDir) {
        List<Integer> numbers = listStressFileNumbers(logDir);
        Collections.sort(numbers);

        if (numbers.size() == FILE_COUNT) {
            int low = numbers.get(0);
            boolean consecutive = true;
            for (int i = 0; i < FILE_COUNT; i++) {
                if (numbers.get(i) != low + i) {
                    consecutive = false;
                    break;
                }
            }
            if (consecutive) {
                return low;
            }
        }

        System.err.println("Expected exactly " + FILE_COUNT + " files matching " + PREFIX + "<N>" + SUFFIX
                + " with consecutive sequence numbers (e.g. " + PREFIX + "1" + SUFFIX + " .. "
                + PREFIX + FILE_COUNT + SUFFIX + ") in " + logDir + ", found: " + numbers);
        System.err.println("Place them manually, or rerun with --seed to create "
                + PREFIX + "1" + SUFFIX + " .. " + PREFIX + FILE_COUNT + SUFFIX + ".");
        System.exit(1);
        return -1; // unreachable
    }

    private static List<Integer> listStressFileNumbers(Path logDir) {
        List<Integer> numbers = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logDir)) {
            for (Path f : stream) {
                if (!Files.isRegularFile(f)) {
                    continue;
                }
                Matcher m = STRESS_FILE_PATTERN.matcher(f.getFileName().toString());
                if (m.matches()) {
                    numbers.add(Integer.parseInt(m.group(1)));
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to list " + logDir + ": " + e.getMessage());
            System.exit(1);
        }
        return numbers;
    }

    /**
     * Renames the 10 files in the current [low, low+FILE_COUNT-1] window up
     * by one, highest number first so each rename's target is always free
     * (already vacated by the previous rename in this same cycle).
     */
    private static int rotateOnce(Path logDir, int low) {
        for (int n = low + FILE_COUNT - 1; n >= low; n--) {
            Path from = logDir.resolve(PREFIX + n + SUFFIX);
            Path to = logDir.resolve(PREFIX + (n + 1) + SUFFIX);
            try {
                Files.move(from, to);
            } catch (NoSuchFileException e) {
                System.err.println("Expected file missing (did something else touch the folder?): " + from);
            } catch (FileAlreadyExistsException e) {
                System.err.println("Target already exists, skipping (unexpected): " + to);
            } catch (IOException e) {
                System.err.println("Failed to rename " + from + " -> " + to + ": " + e.getMessage());
            }
        }
        int newLow = low + 1;
        log("Rotated to " + PREFIX + newLow + SUFFIX + " .. " + PREFIX + (newLow + FILE_COUNT - 1) + SUFFIX);
        return newLow;
    }

    private static void log(String msg) {
        System.out.println(LocalTime.now().format(TIMESTAMP) + " " + msg);
    }

    private StressRotator() {
    }
}
